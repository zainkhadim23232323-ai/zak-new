# صرف Android فون سے APK بنانے کا طریقہ

اس طریقے میں Android Studio کی ضرورت نہیں، مگر GitHub اکاؤنٹ اور انٹرنیٹ ضروری ہیں۔ APK GitHub کے cloud computer پر build ہوگی۔

## 1) ZIP ڈاؤن لوڈ کریں
`AITradingPro_Android_Project.zip` فون میں محفوظ کریں۔

## 2) GitHub پر repository بنائیں
1. Chrome میں https://github.com کھولیں اور sign in / sign up کریں۔
2. `+` > `New repository` دبائیں۔
3. نام `AITradingPro` رکھیں، Public یا Private منتخب کریں، پھر Create repository۔

## 3) Project ZIP اپ لوڈ کریں
1. نئی repository میں `Add file` > `Upload files` منتخب کریں۔
2. فون کے Downloads سے `AITradingPro_Android_Project.zip` منتخب کریں۔
3. نیچے `Commit changes` دبائیں۔

## 4) Build workflow فائل بنائیں
1. Repository میں `Add file` > `Create new file` منتخب کریں۔
2. فائل کا نام بالکل یہ رکھیں: `.github/workflows/android-build.yml`
3. نیچے دیا گیا پورا متن paste کریں، پھر `Commit changes` دبائیں:

```yaml
name: Build Android APK
on:
  workflow_dispatch:
  push:
    paths:
      - "AITradingPro_Android_Project.zip"
      - ".github/workflows/android-build.yml"
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - name: Extract Android project
        run: |
          unzip -q AITradingPro_Android_Project.zip -d source
          test -d source/AITradingPro
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: "17"
      - uses: gradle/actions/setup-gradle@v4
        with:
          gradle-version: "8.13"
      - name: Build debug APK
        run: gradle -p source/AITradingPro :app:assembleDebug
      - uses: actions/upload-artifact@v4
        with:
          name: AI-Trading-Pro-debug-APK
          path: source/AITradingPro/app/build/outputs/apk/debug/app-debug.apk
          if-no-files-found: error
```

## 5) APK حاصل کریں
1. Repository کے `Actions` tab میں جائیں۔
2. `Build Android APK` workflow کا run کھولیں۔
3. مکمل ہونے پر نیچے `Artifacts` میں `AI-Trading-Pro-debug-APK` دبائیں۔
4. ڈاؤن لوڈ شدہ artifact ZIP extract کریں۔
5. `app-debug.apk` کھولیں اور Android کی اجازت مانگنے پر صرف اسی APK کو install کرنے کی اجازت دیں جسے آپ نے اپنے GitHub build سے حاصل کیا ہو۔

## Troubleshooting
- اگر workflow نہ چلے تو `Actions` tab میں GitHub Actions enable کریں۔
- اگر build fail ہو تو run کھول کر سرخ error کا screenshot بھیجیں۔
- پہلی build میں چند منٹ لگ سکتے ہیں۔
- یہ debug APK ہے؛ Play Store release/signing کے لیے الگ release process درکار ہے۔
