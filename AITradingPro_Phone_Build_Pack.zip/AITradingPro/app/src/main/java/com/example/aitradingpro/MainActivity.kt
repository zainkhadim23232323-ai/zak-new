package com.example.aitradingpro

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.delay
import kotlinx.coroutines.withContext
import org.json.JSONArray
import java.net.HttpURLConnection
import java.net.URL
import kotlin.math.abs
import kotlin.math.max
import kotlin.math.min
import kotlin.math.sqrt

private val Bg = Color(0xFF0B1220)
private val Panel = Color(0xFF151F30)
private val Green = Color(0xFF24D18A)
private val Red = Color(0xFFFF6577)
private val Muted = Color(0xFF9BAAC0)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { TradingApp() }
    }
}

data class MarketCoin(
    val symbol: String, val price: Double, val change: Double,
    val quoteVolume: Double, val signal: String, val confidence: Int,
    val entry: Double, val stop: Double, val target1: Double, val target2: Double,
    val rsi: Double, val emaFast: Double, val emaSlow: Double, val note: String
)

data class NewsItem(val title: String, val source: String)

private suspend fun getText(url: String): String = withContext(Dispatchers.IO) {
    val conn = (URL(url).openConnection() as HttpURLConnection)
    conn.connectTimeout = 9000
    conn.readTimeout = 9000
    conn.setRequestProperty("User-Agent", "AITradingPro/1.0")
    try {
        conn.inputStream.bufferedReader().use { it.readText() }
    } finally { conn.disconnect() }
}

private fun ema(values: List<Double>, period: Int): Double {
    if (values.isEmpty()) return 0.0
    val k = 2.0 / (period + 1)
    var result = values.take(min(period, values.size)).average()
    for (v in values.drop(min(period, values.size))) result = v * k + result * (1 - k)
    return result
}

private fun rsi(values: List<Double>, period: Int = 14): Double {
    if (values.size <= period) return 50.0
    val changes = values.zipWithNext { a, b -> b - a }.takeLast(period)
    val gains = changes.filter { it > 0 }.sum() / period
    val losses = changes.filter { it < 0 }.sum().let { abs(it) } / period
    if (losses == 0.0) return 100.0
    return 100.0 - (100.0 / (1.0 + gains / losses))
}

private fun analyze(symbol: String, price: Double, change: Double, volume: Double, closes: List<Double>): MarketCoin {
    val fast = ema(closes, 9)
    val slow = ema(closes, 21)
    val r = rsi(closes)
    val macdFast = ema(closes, 12)
    val macdSlow = ema(closes, 26)
    val macd = macdFast - macdSlow
    val prior = closes.dropLast(1)
    val priorFast = ema(prior, 9)
    val priorSlow = ema(prior, 21)
    val bullish = (fast > slow).compareTo(false) + (macd > 0).compareTo(false) +
            (r in 50.0..68.0).compareTo(false) + (change > 0).compareTo(false)
    val bearish = (fast < slow).compareTo(false) + (macd < 0).compareTo(false) +
            (r in 32.0..50.0).compareTo(false) + (change < 0).compareTo(false)
    val signal = when {
        bullish >= 3 -> "BUY"
        bearish >= 3 -> "SELL"
        else -> "WAIT"
    }
    val confidence = when(signal) {
        "BUY" -> min(92, 58 + bullish * 8 + if (r in 52.0..65.0) 4 else 0)
        "SELL" -> min(92, 58 + bearish * 8 + if (r in 35.0..48.0) 4 else 0)
        else -> 50 + abs(bullish - bearish) * 3
    }
    val atrProxy = closes.takeLast(14).let { if (it.size > 1) it.zipWithNext { a,b -> abs(b-a) }.average() else price * .01 }
    val risk = max(atrProxy * 1.5, price * .004)
    val isBuy = signal == "BUY"
    val entry = price
    val stop = if (isBuy) price - risk else price + risk
    val t1 = if (isBuy) price + risk * 1.5 else price - risk * 1.5
    val t2 = if (isBuy) price + risk * 2.5 else price - risk * 2.5
    val note = when {
        signal == "WAIT" -> "Mixed confirmations; wait for clearer setup."
        r > 70 -> "RSI overbought: avoid chasing; wait for pullback."
        r < 30 -> "RSI oversold: possible bounce; confirm before entry."
        fast > slow -> "EMA 9 above EMA 21; bullish momentum confirmation."
        else -> "EMA 9 below EMA 21; bearish momentum confirmation."
    }
    return MarketCoin(symbol, price, change, volume, signal, confidence, entry, stop, t1, t2, r, fast, slow, note)
}

private suspend fun loadSpot(): List<MarketCoin> {
    val tickers = JSONArray(getText("https://api.binance.com/api/v3/ticker/24hr"))
    val chosen = (0 until tickers.length()).map { tickers.getJSONObject(it) }
        .filter { it.getString("symbol").endsWith("USDT") && !it.getString("symbol").contains("UP") && !it.getString("symbol").contains("DOWN") }
        .sortedByDescending { it.optDouble("quoteVolume") }.take(24)
    return chosen.mapNotNull { t ->
        try {
            val symbol = t.getString("symbol")
            val price = t.getString("lastPrice").toDouble()
            val klines = JSONArray(getText("https://api.binance.com/api/v3/klines?symbol=$symbol&interval=15m&limit=100"))
            val closes = (0 until klines.length()).map { klines.getJSONArray(it).getString(4).toDouble() }
            analyze(symbol, price, t.getString("priceChangePercent").toDouble(),
                t.optDouble("quoteVolume"), closes)
        } catch (_: Exception) { null }
    }
}

private suspend fun loadFutures(): List<MarketCoin> {
    val tickers = JSONArray(getText("https://fapi.binance.com/fapi/v1/ticker/24hr"))
    val chosen = (0 until tickers.length()).map { tickers.getJSONObject(it) }
        .filter { it.getString("symbol").endsWith("USDT") }
        .sortedByDescending { it.optDouble("quoteVolume") }.take(24)
    return chosen.mapNotNull { t ->
        try {
            val symbol = t.getString("symbol")
            val price = t.getString("lastPrice").toDouble()
            val klines = JSONArray(getText("https://fapi.binance.com/fapi/v1/klines?symbol=$symbol&interval=15m&limit=100"))
            val closes = (0 until klines.length()).map { klines.getJSONArray(it).getString(4).toDouble() }
            analyze(symbol, price, t.getString("priceChangePercent").toDouble(),
                t.optDouble("quoteVolume"), closes)
        } catch (_: Exception) { null }
    }
}

private suspend fun loadNews(): List<NewsItem> = withContext(Dispatchers.IO) {
    try {
        val xml = getText("https://www.coindesk.com/arc/outboundfeeds/rss/")
        val parser = android.util.Xml.newPullParser()
        parser.setInput(xml.reader())
        val result = mutableListOf<NewsItem>()
        var event = parser.eventType
        var inItem = false
        var title = ""
        while (event != org.xmlpull.v1.XmlPullParser.END_DOCUMENT && result.size < 8) {
            if (event == org.xmlpull.v1.XmlPullParser.START_TAG) {
                when(parser.name) {
                    "item" -> { inItem = true; title = "" }
                    "title" -> if (inItem) title = parser.nextText()
                }
            } else if (event == org.xmlpull.v1.XmlPullParser.END_TAG && parser.name == "item") {
                if (title.isNotBlank()) result.add(NewsItem(title, "CoinDesk RSS"))
                inItem = false
            }
            event = parser.next()
        }
        result
    } catch (_: Exception) { emptyList() }
}

@Composable
fun TradingApp() {
    var mode by remember { mutableStateOf("SPOT") }
    var selected by remember { mutableStateOf("BTCUSDT") }
    var coins by remember { mutableStateOf<List<MarketCoin>>(emptyList()) }
    var news by remember { mutableStateOf<List<NewsItem>>(emptyList()) }
    var loading by remember { mutableStateOf(false) }
    var error by remember { mutableStateOf("") }
    var lastUpdated by remember { mutableStateOf("Not loaded") }
    var timeframe by remember { mutableStateOf("15m") }

    suspend fun refresh() {
        loading = true
        error = ""
        try {
            coins = if (mode == "SPOT") loadSpot() else loadFutures()
            if (coins.none { it.symbol == selected }) selected = coins.firstOrNull()?.symbol ?: "BTCUSDT"
            lastUpdated = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
        } catch (e: Exception) {
            error = "Market data unavailable: ${e.message ?: "network/API error"}"
        }
        loading = false
    }

    LaunchedEffect(mode) {
        refresh()
        news = loadNews()
        while (true) { delay(30_000); refresh() }
    }

    val current = coins.firstOrNull { it.symbol == selected }
    MaterialTheme(colorScheme = darkColorScheme(
        primary = Green, background = Bg, surface = Panel,
        onBackground = Color.White, onSurface = Color.White
    )) {
        Surface(Modifier.fillMaxSize(), color = Bg) {
            LazyColumn(
                modifier = Modifier.fillMaxSize().padding(horizontal = 16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(top = 24.dp, bottom = 28.dp)
            ) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                        Column {
                            Text("AI TRADING PRO", color = Color.White, fontSize = 21.sp, fontWeight = FontWeight.Bold)
                            Text("Live market scanner • Binance public data", color = Muted, fontSize = 11.sp)
                        }
                        Text(if (loading) "SYNC..." else "● LIVE", color = Green, fontWeight = FontWeight.Bold)
                    }
                }
                item {
                    Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        listOf("SPOT", "FUTURES").forEach { tab ->
                            FilterChip(selected = mode == tab, onClick = { mode = tab }, label = { Text(tab) })
                        }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { /* refresh via keyed state below */ }) { Text("Updated $lastUpdated", color = Muted, fontSize = 10.sp) }
                    }
                }
                if (error.isNotBlank()) item { Text(error, color = Red) }
                item {
                    Card(colors = CardDefaults.cardColors(containerColor = Panel), shape = RoundedCornerShape(18.dp)) {
                        Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text("SELECTED MARKET", color = Muted, fontSize = 11.sp)
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text(current?.symbol ?: selected, fontSize = 22.sp, fontWeight = FontWeight.Bold)
                                Text(current?.let { "$" + fmt(it.price) } ?: "Loading...", fontSize = 20.sp, fontWeight = FontWeight.Bold)
                            }
                            current?.let { coin ->
                                Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
                                    Text("${if (coin.change >= 0) "+" else ""}${"%.2f".format(coin.change)}%", color = if (coin.change >= 0) Green else Red)
                                    Text("24h volume ${compact(coin.quoteVolume)} USDT", color = Muted, fontSize = 12.sp)
                                }
                                Divider(color = Color(0xFF2B3A50))
                                Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                    Column { Text("AI SIGNAL", color = Muted, fontSize = 10.sp); Text(coin.signal, color = signalColor(coin.signal), fontSize = 24.sp, fontWeight = FontWeight.Black) }
                                    Column(horizontalAlignment = Alignment.End) { Text("MODEL CONFIDENCE", color = Muted, fontSize = 10.sp); Text("${coin.confidence}%", fontSize = 24.sp, fontWeight = FontWeight.Bold) }
                                }
                                Text("Entry  ${fmt(coin.entry)}     Stop  ${fmt(coin.stop)}", color = Color.White, fontSize = 13.sp)
                                Text("TP1  ${fmt(coin.target1)}     TP2  ${fmt(coin.target2)}", color = Green, fontSize = 13.sp)
                                Text("RSI ${"%.1f".format(coin.rsi)}  •  EMA9 ${fmt(coin.emaFast)}  •  EMA21 ${fmt(coin.emaSlow)}", color = Muted, fontSize = 11.sp)
                                Text(coin.note, color = Muted, fontSize = 12.sp)
                            }
                        }
                    }
                }
                item {
                    Text("TIMEFRAME VIEW", color = Muted, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("1m","5m","15m","30m","1h","4h","1d").forEach { tf ->
                            FilterChip(selected = timeframe == tf, onClick = { timeframe = tf }, label = { Text(tf) })
                        }
                    }
                    Text("Note: signal engine currently calculates on 15m candles. Other timeframe selector labels are UI placeholders in this starter build.", color = Muted, fontSize = 10.sp)
                }
                item { Text("TOP MARKET SCANNER", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold) }
                items(coins, key = { it.symbol }) { coin ->
                    Card(
                        onClick = { selected = coin.symbol },
                        colors = CardDefaults.cardColors(containerColor = if (selected == coin.symbol) Color(0xFF20334A) else Panel),
                        shape = RoundedCornerShape(14.dp)
                    ) {
                        Row(Modifier.fillMaxWidth().padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Column(Modifier.weight(1f)) {
                                Text(coin.symbol, color = Color.White, fontWeight = FontWeight.Bold)
                                Text("$${fmt(coin.price)}", color = Muted, fontSize = 12.sp)
                            }
                            Column(horizontalAlignment = Alignment.End) {
                                Text(coin.signal, color = signalColor(coin.signal), fontWeight = FontWeight.Bold)
                                Text("${coin.confidence}% • ${"%.2f".format(coin.change)}%", color = Muted, fontSize = 10.sp)
                            }
                        }
                    }
                }
                item {
                    Text("LATEST CRYPTO NEWS", color = Color.White, fontSize = 16.sp, fontWeight = FontWeight.Bold)
                    if (news.isEmpty()) Text("News feed unavailable right now. Check connection and retry.", color = Muted, fontSize = 12.sp)
                }
                items(news) { n ->
                    Card(colors = CardDefaults.cardColors(containerColor = Panel)) {
                        Column(Modifier.padding(12.dp)) {
                            Text(n.title, color = Color.White, fontSize = 13.sp)
                            Text(n.source, color = Muted, fontSize = 10.sp)
                        }
                    }
                }
                item {
                    Text("Risk warning: signals are rule-based estimates, not guaranteed predictions. No orders are placed. Futures can liquidate your entire margin; use paper trading first.", color = Color(0xFFFFC56B), fontSize = 11.sp)
                    Text("Data: Binance public market endpoints • News: CoinDesk RSS • Auto refresh: 30 seconds", color = Muted, fontSize = 10.sp)
                }
            }
        }
    }
}

private fun signalColor(s: String) = when(s) { "BUY" -> Green; "SELL" -> Red; else -> Color(0xFFFFC56B) }
private fun fmt(v: Double): String = if (v >= 1000) "%,.2f".format(v) else "%.6f".format(v).trimEnd('0').trimEnd('.')
private fun compact(v: Double): String = when { v >= 1e9 -> "%.2fB".format(v/1e9); v >= 1e6 -> "%.2fM".format(v/1e6); v >= 1e3 -> "%.1fK".format(v/1e3); else -> "%.0f".format(v) }
