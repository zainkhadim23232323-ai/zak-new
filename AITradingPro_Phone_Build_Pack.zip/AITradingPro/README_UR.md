# AI Trading Pro — Android starter project

یہ Android Studio project Binance کے public Spot اور USDT-M Futures market endpoints سے market data لیتا ہے۔ کوئی Binance API key درکار نہیں، اور app کوئی order place نہیں کرتی۔

## ابھی شامل فیچرز
- Spot اور Futures کے الگ market scanners
- 24h quote-volume کے لحاظ سے top 24 USDT pairs
- 15m candles پر EMA 9/21، RSI، MACD-based confirmation
- Rule-based BUY / SELL / WAIT signal
- Estimated entry, stop-loss, TP1, TP2
- 30-second refresh
- CoinDesk RSS news headlines
- Dark Android UI

## اہم حدود
یہ مکمل institutional-grade AI system یا guaranteed profitable signal نہیں ہے۔ موجودہ code کا confidence فیصد backtested win probability نہیں ہے۔ 1m تا 1d timeframe selector اس starter build میں صرف UI ہے؛ signal engine فی الحال 15m candles استعمال کرتا ہے۔ News صرف headlines دکھاتی ہے، ان کا AI sentiment/impact score ابھی شامل نہیں۔ Funding rate، open interest، liquidation/whale data، chart drawing، persistent alerts، backtesting engine اور exchange order execution اگلے development milestones ہیں۔ Live trading سے پہلے paper-trading اور historical validation لازمی ہے۔

## Run کرنے کا طریقہ
1. PC یا laptop پر Android Studio install کریں۔
2. ZIP extract کریں۔
3. Android Studio میں **Open** منتخب کرکے `AITradingPro` folder کھولیں۔
4. Gradle sync مکمل ہونے دیں۔ JDK 17 یا Android Studio کا bundled JDK منتخب کریں۔
5. SDK Manager میں Android SDK Platform 36 اور Build Tools install کریں۔
6. Android phone پر Developer options > USB debugging آن کریں، یا Android Studio میں emulator بنائیں۔
7. فون connect کریں اور اوپر سبز **Run ▶** دبائیں۔
8. APK بنانے کے لیے: **Build > Build Bundle(s) / APK(s) > Build APK(s)**۔
9. APK عام طور پر `app/build/outputs/apk/debug/app-debug.apk` میں ملے گی۔

## اگر Gradle sync error آئے
- Android Studio > Settings > Build Tools > Gradle میں Gradle JDK 17 منتخب کریں۔
- Internet connection چیک کریں کیونکہ Gradle dependencies پہلی مرتبہ download ہوں گی۔
- SDK Manager سے Android SDK Platform 36 install کریں۔
- پھر File > Sync Project with Gradle Files دبائیں۔

## Build versions
AGP 8.13.2, Kotlin 2.2.20, Compose BOM 2025.10.01, compileSdk 36, minSdk 26.
